// Function to handle media upload
function uploadMedia() {
  const fileInput = document.getElementById('media-upload');
  const file = fileInput.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function (e) {
      const post = document.createElement('div');
      post.className = 'post';
      if (file.type.startsWith('image')) {
        post.innerHTML = `<img src="${e.target.result}" alt="Uploaded Image">`;
      } else if (file.type.startsWith('video')) {
        post.innerHTML = `<video controls src="${e.target.result}"></video>`;
      }
      document.querySelector('.feed').appendChild(post);
    };
    reader.readAsDataURL(file);
  } else {
    alert('Please select a file to upload.');
  }
}

// Function to handle sign-up form submission
document.getElementById('signup-form').addEventListener('submit', function (e) {
  e.preventDefault();
  alert('Sign up successful!');
  // Redirect to the homepage or login page
  window.location.href = 'index.html';
});